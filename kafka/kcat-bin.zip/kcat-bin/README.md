kcat compiled from source using VS 2022
